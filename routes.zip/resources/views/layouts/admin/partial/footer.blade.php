<footer class="footer">
   
        © 2023 Developed by <a target="_blank" href="http://www.technoparkbd.com/">Techno Park Bangladesh</a>
  
</footer>

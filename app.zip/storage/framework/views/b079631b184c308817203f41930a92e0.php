<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="sales_<?php echo e($item->id); ?>">
        <td class="text-center" style="padding: 0.25rem 0.25rem;"><?php echo e($loop->iteration); ?></td>
        <td class="text-nowrap" style="padding: 4px 0.25rem;"><?php echo e(@$item->invoice); ?></td>
        <td style="padding: 4px 0.25rem;">
            <input type="number" class="form-control input-sm text-end sales_amount" step="any"
                id="sales_amount_<?php echo e($item->id); ?>" name="sales_amount[<?php echo e($item->id); ?>]"
                value="<?php echo e($item->net_amount - $item->return_amount); ?>" placeholder="0.00" readonly>
        </td>
        <td style="padding: 4px 0.25rem;">
            <input type="number" class="form-control input-sm text-end previous_paid" step="any"
                id="previous_paid_<?php echo e($item->id); ?>" name="previous_paid[<?php echo e($item->id); ?>]"
                value="<?php echo e($item->paid); ?>" placeholder="0.00" readonly>
        </td>
        <?php if(@$type == 'Adjust'): ?>
            <?php
                $checked = true;
                if ($advance <= 0) {
                    $checked = false;
                    $paid = 0;
                    $due = $item->net_amount - $item->paid;
                } else {
                    $paid = $advance;
                    $due = $item->net_amount - $item->paid - $advance;
                }
            ?>
            <td style="padding: 4px 0.25rem;">
                <input type="number" class="form-control input-sm text-end amount" step="any"
                    id="amount_<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" name="amount[<?php echo e($item->id); ?>]"
                    max="<?php echo e($item->net_amount - $item->return_amount - $item->paid); ?>" min="0"
                    value="<?php echo e($paid); ?>" placeholder="0.00">
            </td>
            <td style="padding: 4px 0.25rem;">
                <input type="number" class="form-control input-sm text-end due" step="any"
                    id="due_<?php echo e($item->id); ?>" name="due[<?php echo e($item->id); ?>]" value="<?php echo e($due); ?>" readonly
                    placeholder="0.00">
            </td>
            <td style="padding: 4px 0.25rem;" class="text-center">
                <div class="custom-control custom-checkbox mx-auto ps-3">
                    <input type="checkbox" class="custom-control-input sales_id" id="sales_id_<?php echo e($item->id); ?>"
                        name="sales_id[]" data-payable="<?php echo e($item->net_amount - $item->return_amount - $item->paid); ?>"
                        value="<?php echo e($item->id); ?>" id="<?php echo e($item->id); ?>"
                        <?php echo e(@$checked === true ? 'checked' : ''); ?>>
                    <label for="<?php echo e($item->id); ?>" class="custom-control-label"></label>
                </div>
            </td>
        <?php else: ?>
            <td style="padding: 4px 0.25rem;">
                <input type="number" class="form-control input-sm text-end amount" step="any"
                    id="amount_<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" name="amount[<?php echo e($item->id); ?>]"
                    max="<?php echo e($item->net_amount - $item->return_amount - $item->paid); ?>" min="0"
                    placeholder="0.00">
            </td>
            <td style="padding: 4px 0.25rem;">
                <input type="number" class="form-control input-sm text-end due" step="any"
                    id="due_<?php echo e($item->id); ?>" name="due[<?php echo e($item->id); ?>]"
                    value="<?php echo e($item->net_amount - $item->return_amount - $item->paid); ?>" readonly placeholder="0.00">
            </td>
            <td style="padding: 4px 0.25rem;" class="text-center">
                <div class="custom-control custom-checkbox mx-auto ps-3">
                    <input type="checkbox" class="custom-control-input sales_id" name="sales_id[]"
                        data-payable="<?php echo e($item->net_amount - $item->return_amount - $item->paid); ?>"
                        value="<?php echo e($item->id); ?>" id="<?php echo e($item->id); ?>">
                    <label for="<?php echo e($item->id); ?>" class="custom-control-label"></label>
                </div>
            </td>
        <?php endif; ?>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\laragon\www\amar-hostel\resources\views/admin/collection/partial/rows.blade.php ENDPATH**/ ?>
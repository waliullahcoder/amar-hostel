<?php
    if ($errors->any()) {
        foreach ($errors->all() as $error) {
            notify()->error($error, 'Error');
        }
    }
    if (session('success_message')) {
        notify()->success(session('success_message'), 'Success');
    }
?>
<?php /**PATH F:\laragon\www\amar-hostel\resources\views/layouts/admin/partial/alert.blade.php ENDPATH**/ ?>
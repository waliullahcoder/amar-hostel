   <section class="testimonial_area section_gap">
            <div class="container">
                <div class="section_title text-center">
                    <h2 class="title_color">Testimonial from our Clients</h2>
                </div>
                <div class="testimonial_slider owl-carousel">
                    <?php $__currentLoopData = $services['testimonial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <div class="media testimonial_item">
                        <img class="rounded-circle" src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="" loading="lazy" decoding="async">
                        <div class="media-body">
                            <p><?php echo e($item->description); ?></p>
                            <a href="<?php echo e(route('serviceDetails', $item->id)); ?>"><h4 class="sec_h4"><?php echo e($item->name); ?></h4></a>
                        </div>
                    </div>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </section><?php /**PATH F:\laragon\www\amar-hostel\resources\views/layouts/frontend/partial/testimonial.blade.php ENDPATH**/ ?>
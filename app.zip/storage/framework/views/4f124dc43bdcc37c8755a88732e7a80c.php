

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.user.headerDash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container py-5 userdash">
    <div class="row">

        <!-- SIDEBAR -->
        <?php echo $__env->make('frontend.user.userSideBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- MAIN CONTENT -->
        <div class="col-lg-9">
            
            <div class="card shadow-sm">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">🧾 Wallest History</h5>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle">
                                <tr>
                                    <th colspan=6 style="text-align: center;">Sales</th>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <th>Sales ID</th>
                                    <th>Room Name</th>
                                    <th>Seats</th>
                                    <th>Price</th>
                                    <th>Date</th>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <strong><?php echo e($sale->id); ?></strong>
                                        </td>
                                        <td> <strong><?php echo e($sale->product->name); ?></strong></td>
                                       
                                        <td><?php echo e($sale->qty); ?></td>
                                        <td><?php echo e($sale->price); ?></td>
                                        <td>
                                            <?php echo e($sale->created_at->format('d M Y')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            No orders found
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                 <tr>
                                    <th colspan=6 style="text-align: center;">Expense</th>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <th>Expense ID</th>
                                    <th>Transaction</th>
                                    <th>Remark</th>
                                    <th>Price</th>
                                    <th>Date</th>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <strong><?php echo e($expense->id); ?></strong>
                                        </td>
                                        <td> <strong><?php echo e($expense->expense->transaction_no); ?>(<?php echo e($expense->coa->head_name); ?>)</strong></td>
                                        <td> <strong><?php echo e($expense->expense->remarks); ?></strong></td>
                                        <td><?php echo e($expense->amount); ?></td>
                                        <td>
                                            <?php echo e($expense->created_at->format('d M Y')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            No orders found
                                        </td>
                                    </tr>
                                <?php endif; ?>
                        </table>
                    </div>


                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/frontend/user/walletHistory.blade.php ENDPATH**/ ?>
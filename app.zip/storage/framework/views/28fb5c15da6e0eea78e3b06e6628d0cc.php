<?php $__env->startSection('form'); ?>
    <input type="hidden" name="print" value="">
    <input type="hidden" name="filter" value="1">
    <div class="row g-3">
        <div class="col-12">
            <label for="date_range" class="form-label"><b>Date</b></label>
            <input type="text" class="form-control date-range" name="date_range" id="date_range"
                placeholder="Select Date Range" data-time-picker="true" data-format="DD-MM-Y" data-separator=" to "
                autocomplete="off" required
                value="<?php echo e(date('d-m-Y', strtotime($start_date)) . ' to ' . date('d-m-Y', strtotime($end_date))); ?>">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row g-4">
        <div class="col-md-6">
            <div class="row g-4">
                <div class="col-12">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr class="bg-primary text-white">
                                <th colspan="4" class="text-center">Income</th>
                            </tr>
                            <tr>
                                <th class="text-center" width="20">SL#</th>
                                <th>Head Code</th>
                                <th>Head Name</th>
                                <th class="text-end">Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $totalIncome = 0;
                            ?>
                            <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incomeList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $totalIncome += abs($incomeList->debit_amount - $incomeList->credit_amount);
                                ?>
                                <tr>
                                    <th class="text-center"><?php echo e($loop->iteration); ?></th>
                                    <td>
                                        <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($incomeList->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                            target="_blank">
                                            <?php echo e($incomeList->coa->head_code); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($incomeList->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                            target="_blank">
                                            <?php echo e($incomeList->coa->head_name); ?>

                                        </a>
                                    </td>
                                    <td class="text-end">
                                        <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($incomeList->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                            target="_blank">
                                            <?php echo e(number_format(abs($incomeList->debit_amount - $incomeList->credit_amount), 2)); ?>

                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end">Total</th>
                                <th class="text-end"><?php echo e(number_format($totalIncome, 2)); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <table class="table table-bordered table-sm mb-0">
                <thead>
                    <tr class="bg-primary text-white">
                        <th colspan="4" class="text-center">Expense</th>
                    </tr>
                    <tr>
                        <th class="text-center" width="60">SL#</th>
                        <th>Head Code</th>
                        <th>Head Name</th>
                        <th class="text-end">Balance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $totalExpanse = 0;
                    ?>
                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalExpanse += $expense->amount;
                        ?>
                        <tr>
                            <th class="text-center"><?php echo e($loop->iteration + 1); ?></th>
                            <td>
                                <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($expense->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                    target="_blank">
                                    <?php echo e($expense->coa->head_code??'N/A'); ?>

                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($expense->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                    target="_blank">
                                    <?php echo e($expense->coa->head_name??'N/A'); ?>

                                </a>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(Route('admin.head-details.index')); ?>?coa_id=<?php echo e($expense->coa_id); ?>&start_date=<?php echo e($start_date); ?>&end_date=<?php echo e($end_date); ?>&income_statement=1"
                                    target="_blank">
                                    <?php echo e($expense->amount >= 0 ? number_format($expense->amount, 2) : '(' . number_format(abs($expense->amount), 2) . ')'); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total</th>
                        <th class="text-end">
                            <?php echo e($totalExpanse >= 0 ? number_format($totalExpanse, 2) : '(' . number_format(abs($totalExpanse), 2) . ')'); ?>

                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="col-12">
            <?php
                $netIncome = $totalIncome;
            ?>

            <?php if($netIncome > $totalExpanse): ?>
                <h5 class="text-white bg-success text-center mb-0 py-2">Net Profit:
                    <?php echo e(number_format($netIncome - $totalExpanse, 2)); ?>

                </h5>
            <?php endif; ?>

            <?php if($netIncome < $totalExpanse): ?>
                <h5 class="text-white bg-danger text-center mb-0 py-2">Net Lose:
                    <?php echo e(number_format($totalExpanse - $netIncome, 2)); ?>

                </h5>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#dataTable').DataTable({
                "order": false,
                dom: 'lBfrtip',
                buttons: [
                    'excelHtml5',
                    {
                        'text': '<i class="fal fa-file-pdf"></i> Print',
                        'className': 'getPdf',
                    },
                ]
            });

            $(document).on('click', '.getPdf', function(e) {
                e.preventDefault();
                $('input[name="print"]').val('true');
                $('.filter_form').submit();
            });

            $(document).on('click', '#filter_btn', function(e) {
                e.preventDefault();
                $('input[name="print"]').val('');
                $('.filter_form').submit();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.report_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/admin/reports/income-statement/index.blade.php ENDPATH**/ ?>
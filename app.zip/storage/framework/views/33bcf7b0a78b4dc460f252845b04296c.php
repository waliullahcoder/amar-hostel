<footer class="footer-area section_gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title"><?php echo e($global_services['about']->name); ?></h6>
                            <p><?php echo e($global_services['about']->description); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">Navigation Links</h6>
                            <div class="row">
                                <div class="col-4">
                                    <ul class="list_style">
                                        <?php $__currentLoopData = $global_services['footer_col1']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('serviceDetails', $item->id)); ?>"><?php echo e($item->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <div class="col-4">
                                    <ul class="list_style">
                                       <?php $__currentLoopData = $global_services['footer_col2']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('serviceDetails', $item->id)); ?>"><?php echo e($item->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>										
                            </div>							
                        </div>
                    </div>							
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">Social Links</h6>
                            
                    <a href="<?php echo e($settings->facebook_page); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="<?php echo e($settings->twitter); ?>" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="<?php echo e($settings->instagram); ?>" target="_blank"><i class="fab fa-dribbble"></i></a>
                <a href="<?php echo e($settings->linkedin); ?>" target="_blank"><i class="fab fa-behance"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget instafeed">
                            <h6 class="footer_title">InstaFeed</h6>
                            <ul class="list_style instafeed d-flex flex-wrap">
                                 <?php $__currentLoopData = $global_services['gallery']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="" loading="lazy" decoding="async" style="width: 50px; height: 50px; object-fit: cover;"></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>						
                </div>
                <div class="border_line"></div>
                <div class="row footer-bottom d-flex justify-content-between align-items-center">
                    <p class="col-lg-8 col-sm-12 footer-text m-0"><!-- Link back to TechnoPark can't be removed. Template is licensed under CC BY 3.0. -->
Copyright ©<script>document.write(new Date().getFullYear());</script>2026 All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://technoparkbd.com" target="_blank">TechnoPark</a>
<!-- Link back to TechnoPark can't be removed. Template is licensed under CC BY 3.0. --></p>
                  
                </div>
            </div>
        </footer><?php /**PATH F:\laragon\www\amar-hostel\resources\views/layouts/frontend/partial/footer.blade.php ENDPATH**/ ?>
<footer class="footer">
   
        © 2023 Developed by <a target="_blank" href="http://www.technoparkbd.com/">Techno Park Bangladesh</a>
  
</footer>
<?php /**PATH F:\laragon\www\amar-hostel\resources\views/layouts/admin/partial/footer.blade.php ENDPATH**/ ?>
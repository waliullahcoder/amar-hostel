

<?php $__env->startSection('content'); ?>

<!--================ Breadcrumb Area =================-->
<section class="breadcrumb_area">
    <div class="container">
        <div class="page-cover text-center">
            <h2 class="page-cover-tittle">Sign In</h2>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="active">Admin Login</li>
            </ol>
        </div>
    </div>
</section>
<!--================ Breadcrumb Area =================-->

<!--================ Login Area =================-->
<section class="contact_area section_gap">
    <div class="container">
        <div class="row justify-content-center align-items-center">

            <div class="col-md-6 col-lg-5">
                <div class="card shadow"
                     style="border:1px solid #eee; border-radius:16px;">
                    
                    <div class="card-body" style="padding:40px 35px;">
                        
                        
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger text-center"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>

                        
                        <?php if(session('success')): ?>
                            <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <!-- Login Form -->
                        <form action="<?php echo e(route('user.signinPost')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <!-- Username -->
                            <div class="form-group mb-3">
                                <input type="text"
                                       name="email"
                                       value="<?php echo e(old('email')); ?>"
                                       class="form-control rounded-pill py-2 px-3 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="Email Address"
                                       required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Password -->
                            <div class="form-group mb-3 position-relative">
                                <input type="password"
                                       name="password"
                                       id="password"
                                       class="form-control rounded-pill py-2 px-3 pe-5 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       placeholder="Password"
                                       required>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Remember / Forgot -->
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="form-check">
                                    <input class="form-check-input"
                                           type="checkbox"
                                           name="remember"
                                           id="remember"
                                           <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="remember">
                                        Remember Me
                                    </label>
                                </div>

                                <a href="#" class="small text-muted">Forgot Password?</a>
                            </div>

                            <!-- Submit -->
                            <div class="text-center">
                                <button type="submit"
                                        class="btn theme_btn button_hover w-100 py-2 rounded-pill">
                                    Sign In
                                </button>
                            </div>

                            <!-- Signup link -->
                            <p class="text-center mt-3 mb-0">
                                Don’t have an account?
                                <a href="<?php echo e(route('auth.signupPage')); ?>">Sign Up</a>
                            </p>

                        </form>
                        <!-- Login Form End -->

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--================ Login Area =================-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/frontend/auth/signin.blade.php ENDPATH**/ ?>
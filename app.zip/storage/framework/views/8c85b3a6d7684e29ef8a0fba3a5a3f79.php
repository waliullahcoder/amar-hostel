 <section class="facilities_area section_gap">
            <div class="overlay bg-parallax" data-stellar-ratio="0.8" data-stellar-vertical-offset="0" data-background="">  
            </div>
            <div class="container">
                <div class="section_title text-center">
                    <h2 class="title_w">Royal Facilities</h2>
                </div>
                <div class="row mb_30">
                    <?php $__currentLoopData = $services['home']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="<?php echo e($service->icon); ?>"></i><?php echo e($service->name); ?></h4>
                            <p><?php echo e(\Illuminate\Support\Str::limit($service->description, 99)); ?> <a href="<?php echo e(route('serviceDetails', $service->id)); ?>">Read More..</a></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                </div>
            </div>
        </section><?php /**PATH F:\laragon\www\amar-hostel\resources\views/layouts/frontend/partial/services.blade.php ENDPATH**/ ?>
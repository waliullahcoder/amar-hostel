

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.user.headerDash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container py-5 userdash">
    <div class="row">
        
        <?php echo $__env->make('frontend.user.userSideBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="col-lg-9">

            <div class="card shadow-sm">
                <div class="card-body" style="padding: 30px 20px; margin: 20px;">

                    <h4 class="mb-4 text-center">Update Profile</h4>

                    <form action="<?php echo e(route('user.profile.update')); ?>"
                          method="POST"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row g-4">

                            
                            <div class="col-md-4 text-center">

                                <img
                                    src="<?php echo e(auth()->user()->image
                                        ? asset(auth()->user()->image)
                                        : asset('frontend/images/user.png')); ?>"
                                    class="rounded-circle mb-3"
                                    width="140"
                                    height="140"
                                    style="object-fit:cover">

                                <div class="mb-2">
                                    <input type="file"
                                           name="image"
                                           class="form-control">
                                </div>

                                <small class="text-muted d-block">
                                    JPG / PNG (Max 2MB)
                                </small>

                            </div>

                            
                            <div class="col-md-8">

                                <div class="mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text"
                                           name="name"
                                           value="<?php echo e(old('name', auth()->user()->name)); ?>"
                                           class="form-control"
                                           required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email"
                                           name="email"
                                           value="<?php echo e(old('email', auth()->user()->email)); ?>"
                                           class="form-control"
                                           required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="text"
                                           name="phone"
                                           value="<?php echo e(old('phone', auth()->user()->phone)); ?>"
                                           class="form-control">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Address</label>
                                    <input type="text"
                                           name="address"
                                           placeholder="House#12, Road#04, Block#C, Badda, Dhaka"
                                           value="<?php echo e(old('address', auth()->user()->address)); ?>"
                                           class="form-control">
                                </div>

                            </div>

                        </div>

                        <div class="text-end mt-4">
                            <button class="btn btn-primary px-5">
                                Update Profile
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/frontend/user/profile_edit.blade.php ENDPATH**/ ?>
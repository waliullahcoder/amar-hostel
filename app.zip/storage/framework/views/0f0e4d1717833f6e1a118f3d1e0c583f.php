<!DOCTYPE html>
<html>
<head>
    <title>Invoice #ORDNO<?php echo e($order->id); ?></title>

    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 13px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border:1px solid #ddd;
            padding:8px;
        }

        th {
            background:#f5f5f5;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .company-info h3 {
            margin: 0;
        }

        .invoice-meta {
            text-align: right;
        }

        .badge {
            background: #dc3545;
            color: #fff;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        .no-print {
            text-align: right;
            margin-bottom: 15px;
        }

        .print-btn {
            background:#dc3545;
            color:#fff;
            padding:8px 16px;
            border:none;
            border-radius:4px;
            cursor:pointer;
        }

        .section {
            margin-bottom: 20px;
        }

        @media print {
            .no-print {
                display: none !important;
            }
        }
        @media print {

    body {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    table {
        border-collapse: collapse !important;
    }

    table, th, td {
        border: 1px solid #000 !important;
    }

    th {
        background: #f5f5f5 !important;
    }

    .no-print {
        display: none !important;
    }
}
    </style>
</head>
<body>


<div class="no-print">
    <button onclick="window.print()" class="print-btn">🖨 Print Invoice</button>
</div>


<div class="header">
    <div class="company-info">
        <img src="<?php echo e(asset($settings->logo)); ?>" height="50" alt="Logo">
        <h3><?php echo e($settings->app_name); ?></h3>
        <p>
            📧 <?php echo e($settings->primary_email); ?> <br>
            ☎ <?php echo e($settings->primary_phone); ?> <br>
            📍 <?php echo e($settings->address ?? 'Bangladesh'); ?>

        </p>
    </div>

    <div class="invoice-meta">
        <h2>INVOICE</h2>
        <p>
            <strong>No:</strong> #ORDNO<?php echo e($order->id); ?> <br>
            <strong>Date:</strong> <?php echo e($order->created_at->format('d M Y')); ?> <br>
            <span class="badge"><?php echo e(ucfirst($order->status)); ?></span>
        </p>
    </div>
</div>

<hr>


<div class="section">
    <table>
        <tr>
            <td width="50%">
                <strong>Bill From:</strong><br>
                <?php echo e($settings->app_name); ?><br>
                <?php echo e($settings->primary_email); ?><br>
                <?php echo e($settings->primary_phone); ?>

            </td>
            <td width="50%">
                <strong>Bill To:</strong><br>
                <?php echo e($order->user->name); ?><br>
                <?php echo e($order->user->email); ?>

            </td>
        </tr>
    </table>
</div>



<div class="section">
    <table>
        <thead>
            <tr>
                <th style="text-align:left;">Product</th>
                <th>Type</th>
                <th class="text-center">Qty</th>
                <th class="text-right">Price</th>
                <th style="text-align:right;">Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($order->room->name); ?></td>
                <td style="text-align:center;"><?php echo e($order->room->category->name ?? '-'); ?></td>
                <td style="text-align:center;"><?php echo e($order->guests); ?></td>
                <td style="text-align:center;">৳ <?php echo e(number_format($order->room->price,2)); ?></td>
                <td style="text-align:right;">৳ <?php echo e(number_format($order->total_price,2)); ?></td>
            </tr>
        </tbody>
    </table>
</div>


<div class="section">
    <table>
        <tr>
            <td width="70%"></td>
            <td width="30%">
                <table>
                    <tr>
                        <td>Subtotal</td>
                        <td style="text-align:right;">৳ <?php echo e(number_format($order->total_price,2)); ?></td>
                    </tr>
                    <tr>
                        <th>Grand Total</th>
                        <th style="text-align:right;">৳ <?php echo e(number_format($order->total_price,2)); ?></th>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</div>

<hr>

<p style="text-align:center;font-size:12px;">
    Thank you for shopping with <strong><?php echo e($settings->app_name); ?></strong> ❤️
</p>

</body>
</html>
<?php /**PATH F:\laragon\www\amar-hostel\resources\views/frontend/order/invoice.blade.php ENDPATH**/ ?>
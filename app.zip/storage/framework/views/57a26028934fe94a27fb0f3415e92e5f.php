<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="row g-3">
        <div class="col-lg-4 col-sm-6">
            <label for="name" class="form-label"><b>Investor Name <span class="text-danger">*</span></b></label>
            <input type="text" class="form-control" id="name" name="name" required value="<?php echo e(old('name')); ?>"
                placeholder="Investor Name">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="email" class="form-label"><b>Email</b></label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>"
                placeholder="Email">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="phone" class="form-label"><b>Phone No. <span class="text-danger">*</span></b></label>
            <input type="number" class="form-control" id="phone" name="phone" required value="<?php echo e(old('phone')); ?>"
                placeholder="Phone">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="nid" class="form-label"><b>NID No.</b></label>
            <input type="number" class="form-control" id="nid" name="nid" value="<?php echo e(old('nid')); ?>"
                placeholder="NID No.">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="address" class="form-label"><b>Address</b></label>
            <input type="text" name="address" id="address" class="form-control" placeholder="Address"
                value="<?php echo e(old('address')); ?>">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="document" class="form-label"><b>Document</b></label>
            <input type="file" name="document" id="document" class="form-control">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="bkash" class="form-label"><b>Bkash Account</b></label>
            <input type="number" name="bkash" id="bkash" class="form-control" placeholder="Bkash Account"
                value="<?php echo e(old('bkash')); ?>">
        </div>
        
        <div class="col-lg-4 col-sm-6">
            <label for="nagad" class="form-label"><b>Nagad Account</b></label>
            <input type="number" name="nagad" id="nagad" class="form-control" placeholder="Nagad Account"
                value="<?php echo e(old('nagad')); ?>">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="bank" class="form-label"><b>Bank - Branch</b></label>
            <input type="text" name="bank" id="bank" class="form-control" placeholder="Bank Name"
                value="<?php echo e(old('bank')); ?>">
        </div>
        
        <div class="col-lg-4 col-sm-6">
            <label for="account_name" class="form-label"><b>Account Name</b></label>
            <input type="text" name="account_name" id="account_name" class="form-control" placeholder="Account Name"
                value="<?php echo e(old('account_name')); ?>">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="account_no" class="form-label"><b>Account Number</b></label>
            <input type="number" name="account_no" id="account_no" class="form-control" placeholder="Account Number"
                value="<?php echo e(old('account_no')); ?>">
        </div>
        <div class="col-lg-4 col-sm-6">
            <label for="image" class="form-label"><b>Image</b></label>
            <input type="file" class="form-control" name="image" id="image" accept="image/*">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.create_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/admin/investor/create.blade.php ENDPATH**/ ?>
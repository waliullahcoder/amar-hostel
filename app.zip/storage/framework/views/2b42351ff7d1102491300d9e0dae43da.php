

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.user.headerDash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="container py-5 userdash">
    <div class="row">
        <?php echo $__env->make('frontend.user.userSideBar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="col-lg-9">
            <div class="card shadow-sm">
                <div class="card-body">

                    <div class="d-flex justify-content-between mb-3">
                        <h5>Order #ORDNO<?php echo e($order->id); ?></h5>
                        <a href="<?php echo e(route('orders.invoice', $order)); ?>"
                           class="btn btn-sm btn-outline-primary">
                            📄 Download Invoice
                        </a>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Type</th>
                                <th>Qty</th>
                                <th>Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                                <tr>
                                    <td><?php echo e($order->room->name); ?></td>
                                    <td>
                                        <?php echo e($order->room->category->name ?? '-'); ?>

                                    </td>
                                    <td><?php echo e($order->guests); ?></td>
                                    <td>৳ <?php echo e(number_format($order->room->price,2)); ?></td>
                                    <td>৳ <?php echo e(number_format($order->total_price,2)); ?></td>
                                </tr>
                                 <tr>
                                    <td><h5>Grand Total:</h5> </td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                  <td><h5>৳ <?php echo e(number_format($order->total_price,2)); ?></h5></td>
                                </tr>
                        </tbody>
                    </table>

                   

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/frontend/order/show.blade.php ENDPATH**/ ?>
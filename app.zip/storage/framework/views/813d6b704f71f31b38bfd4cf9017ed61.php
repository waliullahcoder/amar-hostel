<?php $__env->startSection('content'); ?>
<?php if(session('error')): ?>
<div class="alert alert-danger">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
    <div class="row g-3">
        <div class="col-sm-6">
            <label for="code" class="form-label"><b>Code</b></label>
            <input type="text" class="form-control" id="code" name="code" value="<?php echo e(old('code')); ?>"
                placeholder="Code">
        </div>
        <div class="col-sm-6">
            <label for="name" class="form-label"><b>Name <span class="text-danger">*</span></b></label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>"
                placeholder="Name" required>
        </div>
        <div class="col-sm-6">
            <label for="region_id" class="form-label"><b>Region <span class="text-danger">*</span></b></label>
            <select name="region_id" id="region_id" class="form-select select" data-placeholder="Select Region" required>
                <option value=""></option>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e(old('region_id') == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-6">
            <label for="area_id" class="form-label"><b>Area <span class="text-danger">*</span></b></label>
            <select name="area_id" id="area_id" class="form-select select" data-placeholder="Select Area" required>
                <option value=""></option>
                <?php
                    $areas = [];
                    if (!is_null(old('region_id'))) {
                        $areas = \App\Models\Area::where('region_id', old('region_id'))
                            ->where('status', true)
                            ->orderBy('name', 'asc')
                            ->get();
                    }
                ?>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e(old('area_id') == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-6">
            <label for="territory_id" class="form-label"><b>Territory <span class="text-danger">*</span></b></label>
            <select name="territory_id" id="territory_id" class="form-select select" data-placeholder="Select Territory"
                required>
                <option value=""></option>
                <?php
                    $territories = [];
                    if (!is_null(old('area_id'))) {
                        $territories = \App\Models\Area::where('area_id', old('area_id'))
                            ->where('status', true)
                            ->orderBy('name', 'asc')
                            ->get();
                    }
                ?>
                <?php $__currentLoopData = $territories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e(old('territory_id') == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-6">
            <label for="contact_person" class="form-label"><b>Contact Person</b></label>
            <input type="text" class="form-control" id="contact_person" name="contact_person"
                value="<?php echo e(old('contact_person')); ?>" placeholder="Contact Person">
        </div>
        <div class="col-sm-6">
            <label for="phone" class="form-label"><b>Phone</b></label>
            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>"
                placeholder="Phone">
        </div>
        <div class="col-sm-6">
            <label for="email" class="form-label"><b>Email</b></label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>"
                placeholder="Email">
        </div>
        <div class="col-sm-6">
            <label for="address" class="form-label"><b>Address</b></label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address')); ?>"
                placeholder="Address">
        </div>
        <div class="col-sm-6">
            <label for="bin_no" class="form-label"><b>BIN No</b></label>
            <input type="text" class="form-control" id="bin_no" name="bin_no" value="<?php echo e(old('bin_no')); ?>"
                placeholder="BIN No">
        </div>
        <div class="col-sm-6">
            <label for="credit_limit" class="form-label"><b>Credit Limit</b></label>
            <input type="number" class="form-control" id="credit_limit" name="credit_limit"
                value="<?php echo e(old('credit_limit')); ?>" placeholder="Credit Limit">
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $(document).on('change', '#region_id', function() {
                var region_id = $(this).val();
                $('#area_id option').remove();
                $('#territory_id option').remove();
                $.ajax({
                    url: '<?php echo e(request()->fullUrl()); ?>',
                    type: 'POST',
                    data: {
                        _method: 'GET',
                        region_id: region_id,
                    },
                    success: function(response) {
                        if (response.status == 'success') {
                            $('#area_id').append('<option value=""></option>');
                            $.each(response.areas, function(key, value) {
                                $('#area_id').append(
                                    `<option value="${value.id}">${value.name}</option>`
                                );
                            });
                        }
                    }
                });
            });

            $(document).on('change', '#area_id', function() {
                var area_id = $(this).val();
                $('#territory_id option').remove();
                $.ajax({
                    url: '<?php echo e(request()->fullUrl()); ?>',
                    type: 'POST',
                    data: {
                        _method: 'GET',
                        area_id: area_id,
                    },
                    success: function(response) {
                        if (response.status == 'success') {
                            $('#territory_id').append('<option value=""></option>');
                            $.each(response.territories, function(key, value) {
                                $('#territory_id').append(
                                    `<option value="${value.id}">${value.name}</option>`
                                );
                            });
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.create_app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\amar-hostel\resources\views/admin/client/create.blade.php ENDPATH**/ ?>
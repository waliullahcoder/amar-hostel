<section class="breadcrumb_area py-4 bg-light">
    <div class="container">
        <div class="page-cover text-center">
            <h2 class="page-cover-tittle">User Dashboard</h2>
            <ol class="breadcrumb justify-content-center">
                <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                <li class="breadcrumb-item active">User Dashboard</li>
            </ol>
        </div>
    </div>
</section>


        <script src="{{ asset('frontend/js/jquery-3.2.1.min.js') }}"></script>
        <script src="{{ asset('frontend/js/popper.js') }}"></script>
        <script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('frontend/js/owl.carousel.min.js') }}"></script>
        <script src="{{ asset('frontend/js/jquery.ajaxchimp.min.js') }}"></script>
        <script src="{{ asset('frontend/js/mail-script.js') }}"></script>
        <script src="{{ asset('frontend/js/bootstrap-datetimepicker.min.js') }}"></script>
        <script src="{{ asset('frontend/js/jquery.nice-select.js') }}"></script>
        <script src="{{ asset('frontend/js/mail-script.js') }}"></script>
        <script src="{{ asset('frontend/js/stellar.js') }}"></script>
        <script src="{{ asset('frontend/js/simpleLightbox.min.js') }}"></script>
        <script src="{{ asset('frontend/js/custom.js') }}"></script>


  <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.css') }}" fetchpriority="high">
        <link rel="stylesheet" href="{{ asset('frontend/css/style_1.css') }}" fetchpriority="high">
        <link rel="stylesheet" href="{{ asset('frontend/css/font-awesome.min.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap-datetimepicker.min.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/nice-select.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/owl.carousel.min.css') }}">
        <!-- main css -->
        <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/custom.css') }}">
        <link rel="stylesheet" href="{{ asset('frontend/css/responsive.css') }}">

        <link rel="stylesheet" href="{{ asset('frontend/css/all.min.css') }}">